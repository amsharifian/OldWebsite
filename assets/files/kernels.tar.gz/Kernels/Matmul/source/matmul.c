/* Starting point for Matrix Multiply Homework
 * By P. Koopman  for CMU 18-742   10/11/97
 */

/* Probably you'll want to remove the three define directives
 * below and go to compiler flags so you can try alternatives
 * from a batch file.
 * Compile with "N" defined for array size
 *              "OFFSET" for row offset value
 *              "FILLER" for inter-array filler value
 *   e.g.,  -DN=512  for a 512x512 array
 *          -DOFFSET=32 for row offset value of 32
 *          -DFILLER=256
 * cc -DN=512 -DOFFSET=32 -DFILLER=3 -O4 matmul.c -o matmul
 * note that the above values are all in terms of 8-byte longs
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/times.h>
#include <sys/types.h>
#define HZ 60

#define N 512
#define OFFSET 32
#define FILLER 256

long a[N][N+OFFSET];
#if (FILLER)
long ax[FILLER];
#endif
long b[N][N+OFFSET];
#if (FILLER)
long bx[FILLER];
#endif
long c[N][N+OFFSET];
#if (FILLER)
long cx[FILLER];
#endif
long gold_c[N][N];

/* modify this routine to improve performance */
void my_matmul(void)
{ int i,j,k;
  long temp;
  for (i=0;i<N;i++)
  { for (j=0;j<N;j++)
    { temp = 0.0;
      for (k=0;k<N;k++)
      { temp += a[i][k]*b[k][j];
      }  /* k */
      c[i][j] = temp;
    } /* j */
  } /* i */
}

/* don't change the routine below -- it is a reference correctness test */

void golden_matmul(void)
{ int i,j,k;
  for (i=0;i<N;i++)
  { for (j=0;j<N;j++)
  	 { gold_c[i][j] = 0.0;
  	   for (k=0;k<N;k++)
       { gold_c[i][j] += a[i][k]*b[k][j];
       }  /* k */
    } /* j */
  } /* i */
}

int matmul_OK(void)
{ int i,j;
  golden_matmul();
  for (i=0;i<N;i++)
  { for (j=0;j<N;j++)
    { if (gold_c[i][j] != c[i][j]) return(0);
    } /* j */
  } /* i */
  return(1);
}

void init_arrays(void)
{ int i,j;
  for (i=0;i<N;i++)
  { for (j=0;j<N;j++)
    { a[i][j] = i * 5 + j * 2;
      b[i][j] = i * 2 + j * 3;
    } /* j */
  } /* i */
}


void main(void)
{ double elapsed;

  struct tms time_info;
  long Begin_Time, End_Time;

  fprintf(stderr, "Matrix multiply timing test\n");
  fprintf(stderr, "Array size=%d   Inter-row offset=%d   Inter-matrix filler=%d\n",
        N, OFFSET, FILLER);

  init_arrays();

  /* start timer */
  times (&time_info);
  Begin_Time = (long) time_info.tms_utime;

  my_matmul();

  /* stop timer */
  times (&time_info);
  End_Time = (long) time_info.tms_utime;
  elapsed = ((double) (End_Time - Begin_Time) ) / HZ ;
  fprintf(stderr, "Elapsed time = %.3f", elapsed);

  if (matmul_OK()) fprintf(stderr, "\nOK\n");
  else fprintf(stderr, " **ERROR IN RESULT!!!\n");
}

